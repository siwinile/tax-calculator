import java.util.Scanner;

public class TaxCalculator {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Get user input for tax year
        int taxYear = getValidTaxYear("Choose tax year (2022, 2023, or 2024): ");

        // Get user input for age
        int age = getPositiveInteger("Enter your age: ");

        // Get user input for annual income
        double annualIncome = getPositiveInput("Enter your annual income: ");

        // Calculate tax based on selected tax year, age, and income
        double taxObligation = calculateTax(annualIncome, age, taxYear);

        // Display the calculated tax obligation
        System.out.println("Your tax obligation for the year " + taxYear + " is: R" + taxObligation);

        scanner.close();
    }

    public static int getValidTaxYear(String prompt) {
        Scanner scanner = new Scanner(System.in);
        int userInput;

        do {
            System.out.print(prompt);
            while (!scanner.hasNextInt()) {
                System.out.println("Invalid input. Please enter a valid year (2022, 2023, or 2024).");
                System.out.print(prompt);
                scanner.next();
            }
            userInput = scanner.nextInt();

            if (userInput < 2022 || userInput > 2024) {
                System.out.println("Invalid input. Please enter a valid year (2022, 2023, or 2024).");
            }

        } while (userInput < 2022 || userInput > 2024);

        return userInput;
    }

    public static int getPositiveInteger(String prompt) {
        Scanner scanner = new Scanner(System.in);
        int userInput;

        do {
            System.out.print(prompt);
            while (!scanner.hasNextInt()) {
                System.out.println("Invalid input. Please enter a valid positive integer for age.");
                System.out.print(prompt);
                scanner.next();
            }
            userInput = scanner.nextInt();

            if (userInput <= 0) {
                System.out.println("Invalid input. Please enter a positive integer for age.");
            }

        } while (userInput <= 0);

        return userInput;
    }

    public static double getPositiveInput(String prompt) {
        Scanner scanner = new Scanner(System.in);
        double userInput;

        do {
            System.out.print(prompt);
            while (!scanner.hasNextDouble()) {
                System.out.println("Invalid input. Please enter a valid positive number for annual income.");
                System.out.print(prompt);
                scanner.next();
            }
            userInput = scanner.nextDouble();

            if (userInput <= 0) {
                System.out.println("Invalid input. Please enter a positive number for annual income.");
            }

        } while (userInput <= 0);

        return userInput;
    }

    public static double calculateTax(double annualIncome, int age, int taxYear) {
        // Tax brackets and rates for the selected tax year
        double[] brackets = { 237100, 370500, 512800, 673000, 857900, 1817000 };
        double[] rates = { 0.18, 0.26, 0.31, 0.36, 0.39, 0.41, 0.45 };

        // Tax rebates for the selected tax year
        double primaryRebate = getRebate("Primary", taxYear);
        double secondaryRebate = getRebate("Secondary", taxYear);
        double tertiaryRebate = getRebate("Tertiary", taxYear);

        // Tax thresholds for the selected tax year
        double under65Threshold = getThreshold("Under 65", taxYear);
        double over65Threshold = getThreshold("65 and older", taxYear);
        double over75Threshold = getThreshold("75 and older", taxYear);

        // Calculate tax based on income, age, and tax brackets
        double taxableIncome = annualIncome;
        double tax = 0;

        for (int i = 0; i < brackets.length; i++) {
            if (taxableIncome <= brackets[i]) {
                tax += taxableIncome * rates[i];
                break;
            } else {
                tax += brackets[i] * rates[i];
                taxableIncome -= brackets[i];
            }
        }

        // Apply rebates
        tax -= primaryRebate;
        if (taxYear >= 2023) {
            tax -= secondaryRebate;
            tax -= tertiaryRebate;
        }

        // Apply thresholds based on age
        switch (ageCategory(age)) {
            case "Under 65":
                if (annualIncome <= under65Threshold) {
                    tax = 0;
                } else if (annualIncome <= over65Threshold) {
                    tax -= under65Threshold * rates[0];
                } else if (annualIncome <= over75Threshold) {
                    tax -= over65Threshold * rates[0];
                }
                break;
            case "65 and older":
                if (annualIncome <= over65Threshold) {
                    tax = 0;
                } else if (annualIncome <= over75Threshold) {
                    tax -= over65Threshold * rates[0];
                }
                break;
            case "75 and older":
                if (annualIncome <= over75Threshold) {
                    tax = 0;
                }
                break;
        }

        return Math.max(0, tax);
    }

    public static double getRebate(String category, int taxYear) {
        switch (category) {
            case "Primary":
                return (taxYear == 2024) ? 17235 : (taxYear == 2023) ? 16425 : 15714;
            case "Secondary":
                return (taxYear == 2024) ? 9444 : (taxYear == 2023) ? 9000 : 8613;
            case "Tertiary":
                return (taxYear == 2024) ? 3145 : (taxYear == 2023) ? 2997 : 2871;
            default:
                return 0;
        }
    }

    public static double getThreshold(String ageCategory, int taxYear) {
        switch (ageCategory) {
            case "Under 65":
                return (taxYear == 2024) ? 95750 : (taxYear == 2023) ? 91250 : 87300;
            case "65 and older":
                return (taxYear == 2024) ? 148217 : (taxYear == 2023) ? 141250 : 135150;
            case "75 and older":
                return (taxYear == 2024) ? 165689 : (taxYear == 2023) ? 157900 : 151100;
            default:
                return 0;
        }
    }

    public static String ageCategory(int age) {
        if (age < 65) {
            return "Under 65";
        } else if (age < 75) {
            return "65 and older";
        } else {
            return "75 and older";
        }
    }
}



